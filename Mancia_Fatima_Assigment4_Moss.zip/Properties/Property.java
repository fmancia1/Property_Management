
public class Property {

}
